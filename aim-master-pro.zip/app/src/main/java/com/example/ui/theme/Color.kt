package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Obsidian & Carbon Canvas
val DarkBackground = Color(0xFF0B0D13)
val DarkSurface = Color(0xFF131722)
val DarkSurfaceVariant = Color(0xFF1C2233)
val DarkSurfaceCard = Color(0xFF181D2C)
val DarkCardBorder = Color(0x33FFB703)
val DarkCardBorderActive = Color(0x80FFB703)

// Gold & Amber Accents
val AmberGoldPrimary = Color(0xFFFFB703)
val AmberGoldSecondary = Color(0xFFFFD166)
val AmberGoldDark = Color(0xFFFB8500)
val GoldGlow = Color(0x4DFFB703)

// Active Engine Emerald Green
val EmeraldGreenPrimary = Color(0xFF10B981)
val EmeraldGreenSecondary = Color(0xFF00F5D4)
val EmeraldGreenDark = Color(0xFF059669)
val EmeraldGlow = Color(0x4D10B981)

// Dynamic Trajectory Colors
val TrajectoryPottingGreen = Color(0xFF00F5D4) // Green for potting trajectory
val TrajectoryCollisionRed = Color(0xFFFF3366) // Red for collision path
val TrajectoryCushionYellow = Color(0xFFFFD166) // Yellow for cushion bounce
val StrikerCyan = Color(0xFF38BDF8)
val BallWhite = Color(0xFFF8FAFC)
val PocketDark = Color(0xFF090A0F)

// Text & Neutral Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextMuted = Color(0xFF475569)

val StatusProGold = Color(0xFFFFD700)
val StatusStandby = Color(0xFF64748B)
