package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AimConfig
import com.example.model.GameMode
import com.example.ui.components.FeatureToggles
import com.example.ui.components.GameSelector
import com.example.ui.components.HeaderProBadge
import com.example.ui.components.LiveTrajectoryCanvas
import com.example.ui.components.PermissionCard
import com.example.ui.components.TelemetryStatsCard
import com.example.ui.theme.AmberGoldDark
import com.example.ui.theme.AmberGoldPrimary
import com.example.ui.theme.AmberGoldSecondary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.EmeraldGreenDark
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.theme.EmeraldGreenSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AimDashboardScreen(
    config: AimConfig,
    isEngineRunning: Boolean,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onToggleEngine: () -> Unit,
    onConfigChange: (AimConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "engine_pulse")
    val pulseGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_glow"
    )

    Scaffold(
        containerColor = DarkBackground,
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Header with Device ID (#YyoixdZJ) and active PRO membership badge
            item {
                HeaderProBadge(
                    deviceId = config.deviceId,
                    isPro = config.isProMember
                )
            }

            // 2. Permission Card
            item {
                PermissionCard(
                    hasOverlayPermission = hasOverlayPermission,
                    onRequestOverlayPermission = onRequestOverlayPermission
                )
            }

            // 3. Large Prominent Start / Stop Cloud Engine Button
            item {
                ProminentEngineToggleButton(
                    isEngineRunning = isEngineRunning,
                    glowAlpha = pulseGlowAlpha,
                    onToggleEngine = onToggleEngine
                )
            }

            // 4. Game Selector: "Carrom Disc Pool (Active)" & "8 Ball Pool (Standby)"
            item {
                GameSelector(
                    selectedGame = config.selectedGame,
                    onGameSelected = { mode ->
                        onConfigChange(config.copy(selectedGame = mode))
                    }
                )
            }

            // 5. Feature Toggles: "Multi-Ray Laser Aim", "Auto Cushion Reflection", "Auto Target Pocket"
            item {
                FeatureToggles(
                    config = config,
                    onConfigChange = onConfigChange
                )
            }

            // 6. Interactive Live Trajectory Simulator Canvas Preview
            item {
                LiveTrajectoryCanvas(
                    config = config
                )
            }

            // 7. Hardware & Engine Telemetry Stats Card
            item {
                TelemetryStatsCard(
                    isEngineRunning = isEngineRunning
                )
            }

            // Footer Anti-Detection & Security Banner
            item {
                SecurityStatusBanner()
            }
        }
    }
}

@Composable
private fun ProminentEngineToggleButton(
    isEngineRunning: Boolean,
    glowAlpha: Float,
    onToggleEngine: () -> Unit
) {
    val buttonColors = if (isEngineRunning) {
        listOf(
            EmeraldGreenDark,
            EmeraldGreenPrimary,
            EmeraldGreenSecondary
        )
    } else {
        listOf(
            AmberGoldDark,
            AmberGoldPrimary,
            AmberGoldSecondary
        )
    }

    val shadowColor = if (isEngineRunning) EmeraldGreenPrimary else AmberGoldPrimary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isEngineRunning) 18.dp else 10.dp,
                shape = RoundedCornerShape(22.dp),
                ambientColor = shadowColor.copy(alpha = glowAlpha),
                spotColor = shadowColor.copy(alpha = glowAlpha)
            )
            .clip(RoundedCornerShape(22.dp))
            .background(
                brush = Brush.horizontalGradient(colors = buttonColors)
            )
            .border(
                width = 2.dp,
                color = Color.White.copy(alpha = if (isEngineRunning) 0.8f else 0.4f),
                shape = RoundedCornerShape(22.dp)
            )
            .clickable { onToggleEngine() }
            .padding(vertical = 18.dp, horizontal = 20.dp)
            .testTag("cloud_engine_toggle_button"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isEngineRunning) Icons.Default.Stop else Icons.Default.PowerSettingsNew,
                    contentDescription = if (isEngineRunning) "Stop Cloud Engine" else "Start Cloud Engine",
                    tint = if (isEngineRunning) Color.White else Color(0xFF1E1402),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = if (isEngineRunning) "STOP CLOUD ENGINE" else "START CLOUD ENGINE",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = if (isEngineRunning) Color.White else Color(0xFF1E1402)
                )
                Text(
                    text = if (isEngineRunning) "TRANSPARENT OVERLAY RUNNING • TAP TO CLOSE" else "PRESS TO LAUNCH FLOATING LASER OVERLAY",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isEngineRunning) Color.White.copy(alpha = 0.85f) else Color(0xFF382602)
                )
            }
        }
    }
}

@Composable
private fun SecurityStatusBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF11141D))
            .border(
                width = 1.dp,
                color = DarkCardBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("security_status_banner")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "Security Guard",
                tint = AmberGoldPrimary,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(
                    text = "MEMORY-INDEPENDENT DRAWING PROTOCOL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Pure optical UI layer rendering with hardware pass-through mode.",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
        }
    }
}
