package com.example.ui.components

import android.graphics.RectF
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AimBall
import com.example.model.AimConfig
import com.example.model.AimPocket
import com.example.model.GameMode
import com.example.model.RayType
import com.example.model.Vec2
import com.example.physics.AimPhysicsEngine
import com.example.ui.theme.AmberGoldPrimary
import com.example.ui.theme.AmberGoldSecondary
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.theme.StrikerCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrajectoryCollisionRed
import com.example.ui.theme.TrajectoryCushionYellow
import com.example.ui.theme.TrajectoryPottingGreen
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun LiveTrajectoryCanvas(
    config: AimConfig,
    modifier: Modifier = Modifier
) {
    var strikerPos by remember { mutableStateOf(Vec2(200f, 310f)) }
    var aimAngleRad by remember { mutableStateOf(-Math.PI.toFloat() * 0.38f) }
    var draggingStriker by remember { mutableStateOf(false) }
    var draggingAimHandle by remember { mutableStateOf(false) }

    // Carrom pucks: Queen (Red), White Puck, Black Puck
    val pucks = remember {
        mutableStateListOf(
            AimBall(1, Vec2(200f, 170f), 20f, colorArgb = 0xFFEF4444.toInt(), label = "Q"), // Red Queen
            AimBall(2, Vec2(145f, 130f), 20f, colorArgb = 0xFFF3F4F6.toInt(), label = "W"), // White Puck
            AimBall(3, Vec2(255f, 140f), 20f, colorArgb = 0xFF1F2937.toInt(), label = "B")  // Black Puck
        )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_phase"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "CARROM TRAJECTORY SIMULATOR",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = AmberGoldPrimary
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(EmeraldGreenPrimary)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = "Drag to Aim",
                    tint = TextMuted,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Drag Striker / Reticle",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        }

        // Square 1:1 Carrom Board
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.0f) // Exact 1:1 square Carrom board
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF1E2436),
                            Color(0xFF11141D),
                            Color(0xFF090B10)
                        )
                    )
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            AmberGoldPrimary.copy(alpha = 0.5f),
                            DarkCardBorder
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val touchVec = Vec2(offset.x, offset.y)
                            val distStriker = touchVec.distanceTo(strikerPos)
                            val aimHandlePos = Vec2(
                                strikerPos.x + cos(aimAngleRad) * 80f,
                                strikerPos.y + sin(aimAngleRad) * 80f
                            )
                            val distHandle = touchVec.distanceTo(aimHandlePos)

                            if (distStriker <= 40f) {
                                draggingStriker = true
                            } else if (distHandle <= 40f) {
                                draggingAimHandle = true
                            } else {
                                // Tap to direct aim
                                val diff = touchVec - strikerPos
                                aimAngleRad = diff.angle()
                            }
                        },
                        onDragEnd = {
                            draggingStriker = false
                            draggingAimHandle = false
                        },
                        onDragCancel = {
                            draggingStriker = false
                            draggingAimHandle = false
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val touchVec = Vec2(change.position.x, change.position.y)
                            if (draggingStriker) {
                                strikerPos = Vec2(
                                    strikerPos.x + dragAmount.x,
                                    strikerPos.y + dragAmount.y
                                )
                            } else {
                                val diff = touchVec - strikerPos
                                aimAngleRad = diff.angle()
                            }
                        }
                    )
                }
                .testTag("live_trajectory_simulator")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasW = size.width
                val canvasH = size.height
                val pad = 24f

                val tableBounds = RectF(pad, pad, canvasW - pad, canvasH - pad)

                // Draw Carrom Wooden Frame Rim
                drawRoundRect(
                    color = Color(0x33FFB703),
                    topLeft = Offset(tableBounds.left, tableBounds.top),
                    size = Size(tableBounds.width(), tableBounds.height()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f),
                    style = Stroke(width = 2.5f)
                )

                // Carrom Center Circle (Queen Circle)
                drawCircle(
                    color = Color(0x22FFB703),
                    center = Offset(tableBounds.centerX(), tableBounds.centerY()),
                    radius = tableBounds.width() * 0.16f,
                    style = Stroke(width = 1.5f)
                )
                drawCircle(
                    color = Color(0x10FFB703),
                    center = Offset(tableBounds.centerX(), tableBounds.centerY()),
                    radius = tableBounds.width() * 0.06f,
                    style = Stroke(width = 1.5f)
                )

                // Baseline Guidelines
                val baselineY = tableBounds.bottom - 48f
                drawLine(
                    color = Color(0x20FFFFFF),
                    start = Offset(tableBounds.left + 40f, baselineY),
                    end = Offset(tableBounds.right - 40f, baselineY),
                    strokeWidth = 1.5f
                )
                // Baseline end circles
                drawCircle(
                    color = Color(0x30FF3366),
                    center = Offset(tableBounds.left + 40f, baselineY),
                    radius = 12f,
                    style = Stroke(width = 1.5f)
                )
                drawCircle(
                    color = Color(0x30FF3366),
                    center = Offset(tableBounds.right - 40f, baselineY),
                    radius = 12f,
                    style = Stroke(width = 1.5f)
                )

                // Setup 4 Carrom Corner Pockets
                val pockets = mutableListOf<AimPocket>()
                val pocketRadius = 26f
                pockets.add(AimPocket(Vec2(tableBounds.left + 10f, tableBounds.top + 10f), pocketRadius, "Top-Left"))
                pockets.add(AimPocket(Vec2(tableBounds.right - 10f, tableBounds.top + 10f), pocketRadius, "Top-Right"))
                pockets.add(AimPocket(Vec2(tableBounds.left + 10f, tableBounds.bottom - 10f), pocketRadius, "Bottom-Left"))
                pockets.add(AimPocket(Vec2(tableBounds.right - 10f, tableBounds.bottom - 10f), pocketRadius, "Bottom-Right"))

                // Draw 4 Corner Pockets
                pockets.forEach { pocket ->
                    drawCircle(
                        color = Color(0xFF07090E),
                        center = Offset(pocket.position.x, pocket.position.y),
                        radius = pocket.radius
                    )
                    drawCircle(
                        color = AmberGoldPrimary.copy(alpha = 0.5f),
                        center = Offset(pocket.position.x, pocket.position.y),
                        radius = pocket.radius,
                        style = Stroke(width = 2.5f)
                    )
                }

                // Clamp striker inside table bounds
                strikerPos = Vec2(
                    strikerPos.x.coerceIn(tableBounds.left + 30f, tableBounds.right - 30f),
                    strikerPos.y.coerceIn(tableBounds.top + 30f, tableBounds.bottom - 30f)
                )

                // Compute Trajectory
                val aimDir = Vec2(cos(aimAngleRad), sin(aimAngleRad))
                val trajectory = AimPhysicsEngine.calculateTrajectory(
                    strikerPos = strikerPos,
                    aimDirection = aimDir,
                    balls = pucks,
                    pockets = pockets,
                    tableBounds = tableBounds,
                    config = config,
                    maxRayDistance = 1200f
                )

                // Draw Trajectory Rays
                trajectory.rays.forEach { ray ->
                    when (ray.type) {
                        RayType.POTTING_TRAJECTORY -> {
                            // GREEN POT LINE
                            drawLine(
                                color = TrajectoryPottingGreen.copy(alpha = 0.35f),
                                start = Offset(ray.start.x, ray.start.y),
                                end = Offset(ray.end.x, ray.end.y),
                                strokeWidth = 10f,
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = TrajectoryPottingGreen,
                                start = Offset(ray.start.x, ray.start.y),
                                end = Offset(ray.end.x, ray.end.y),
                                strokeWidth = 4.5f,
                                cap = StrokeCap.Round
                            )

                            // Pulsing Pocket Target
                            val pulseR = 14f + pulsePhase * 16f
                            drawCircle(
                                color = TrajectoryPottingGreen.copy(alpha = (0.8f * (1f - pulsePhase))),
                                center = Offset(ray.end.x, ray.end.y),
                                radius = pulseR,
                                style = Stroke(width = 2.5f)
                            )
                        }
                        RayType.COLLISION_PATH -> {
                            // RED COLLISION DEFLECTION
                            drawLine(
                                color = TrajectoryCollisionRed.copy(alpha = 0.35f),
                                start = Offset(ray.start.x, ray.start.y),
                                end = Offset(ray.end.x, ray.end.y),
                                strokeWidth = 10f,
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = TrajectoryCollisionRed,
                                start = Offset(ray.start.x, ray.start.y),
                                end = Offset(ray.end.x, ray.end.y),
                                strokeWidth = 4.5f,
                                cap = StrokeCap.Round
                            )
                        }
                        RayType.CUSHION_BOUNCE -> {
                            // YELLOW CUSHION BOUNCE
                            drawLine(
                                color = TrajectoryCushionYellow.copy(alpha = 0.35f),
                                start = Offset(ray.start.x, ray.start.y),
                                end = Offset(ray.end.x, ray.end.y),
                                strokeWidth = 8f,
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = TrajectoryCushionYellow,
                                start = Offset(ray.start.x, ray.start.y),
                                end = Offset(ray.end.x, ray.end.y),
                                strokeWidth = 4f,
                                cap = StrokeCap.Round
                            )
                        }
                        RayType.AIM_GUIDE -> {
                            if (ray.isDashed) {
                                drawLine(
                                    color = AmberGoldPrimary.copy(alpha = 0.5f),
                                    start = Offset(ray.start.x, ray.start.y),
                                    end = Offset(ray.end.x, ray.end.y),
                                    strokeWidth = 2.5f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                                )
                            } else {
                                drawLine(
                                    color = AmberGoldPrimary,
                                    start = Offset(ray.start.x, ray.start.y),
                                    end = Offset(ray.end.x, ray.end.y),
                                    strokeWidth = 3.5f,
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    }
                }

                // Draw Carrom Pucks (Queen, White, Black)
                pucks.forEach { puck ->
                    drawCircle(
                        color = Color(puck.colorArgb),
                        center = Offset(puck.position.x, puck.position.y),
                        radius = puck.radius
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.7f),
                        center = Offset(puck.position.x, puck.position.y),
                        radius = puck.radius,
                        style = Stroke(width = 2f)
                    )
                }

                // Draw Striker
                val strikerRadius = 26f
                drawCircle(
                    color = StrikerCyan.copy(alpha = 0.2f * (1f - pulsePhase * 0.4f)),
                    center = Offset(strikerPos.x, strikerPos.y),
                    radius = strikerRadius + pulsePhase * 8f
                )
                drawCircle(
                    color = Color(0xFF131722),
                    center = Offset(strikerPos.x, strikerPos.y),
                    radius = strikerRadius
                )
                drawCircle(
                    color = StrikerCyan,
                    center = Offset(strikerPos.x, strikerPos.y),
                    radius = strikerRadius,
                    style = Stroke(width = 3f)
                )

                // Aim Reticle Handle
                val handleDist = 80f
                val handlePos = Vec2(
                    strikerPos.x + cos(aimAngleRad) * handleDist,
                    strikerPos.y + sin(aimAngleRad) * handleDist
                )
                drawLine(
                    color = AmberGoldPrimary.copy(alpha = 0.7f),
                    start = Offset(strikerPos.x, strikerPos.y),
                    end = Offset(handlePos.x, handlePos.y),
                    strokeWidth = 2f
                )
                drawCircle(
                    color = AmberGoldPrimary,
                    center = Offset(handlePos.x, handlePos.y),
                    radius = 11f
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.6f),
                    center = Offset(handlePos.x, handlePos.y),
                    radius = 16f,
                    style = Stroke(width = 1.5f)
                )
            }
        }
    }
}

