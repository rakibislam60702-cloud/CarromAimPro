package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChangeCircle
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material.icons.filled.Flare
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AimConfig
import com.example.ui.theme.AmberGoldDark
import com.example.ui.theme.AmberGoldPrimary
import com.example.ui.theme.AmberGoldSecondary
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrajectoryCollisionRed
import com.example.ui.theme.TrajectoryCushionYellow
import com.example.ui.theme.TrajectoryPottingGreen

@Composable
fun FeatureToggles(
    config: AimConfig,
    onConfigChange: (AimConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section Header with Trajectory Color Legend
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PRECISION AI ENGINE FEATURES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                color = AmberGoldPrimary
            )

            // Trajectory Color Legend Pills
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendDot(color = TrajectoryPottingGreen, label = "Pot")
                LegendDot(color = TrajectoryCollisionRed, label = "Hit")
                LegendDot(color = TrajectoryCushionYellow, label = "Rail")
            }
        }

        // 1. Multi-Ray Laser Aim Toggle
        ToggleCard(
            title = "Multi-Ray Laser Aim",
            subtitle = "Predicts parallel optical guide beams for wide field accuracy",
            colorDot = AmberGoldPrimary,
            icon = Icons.Default.Flare,
            isChecked = config.isMultiRayLaser,
            onCheckedChange = { onConfigChange(config.copy(isMultiRayLaser = it)) },
            tag = "toggle_multi_ray_laser"
        )

        // 2. Auto Cushion Reflection Toggle
        ToggleCard(
            title = "Auto Cushion Reflection",
            subtitle = "Computes 2-rail rebound physics (Yellow bounce trajectory)",
            colorDot = TrajectoryCushionYellow,
            icon = Icons.Default.ChangeCircle,
            isChecked = config.isAutoCushionReflection,
            onCheckedChange = { onConfigChange(config.copy(isAutoCushionReflection = it)) },
            tag = "toggle_auto_cushion_reflection"
        )

        // 3. Auto Target Pocket Toggle
        ToggleCard(
            title = "Auto Target Pocket",
            subtitle = "Calculates exact potting vector into nearest pocket (Green line)",
            colorDot = TrajectoryPottingGreen,
            icon = Icons.Default.CrisisAlert,
            isChecked = config.isAutoTargetPocket,
            onCheckedChange = { onConfigChange(config.copy(isAutoTargetPocket = it)) },
            tag = "toggle_auto_target_pocket"
        )
    }
}

@Composable
private fun ToggleCard(
    title: String,
    subtitle: String,
    colorDot: Color,
    icon: ImageVector,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        DarkSurfaceCard,
                        if (isChecked) DarkSurfaceVariant else Color(0xFF10131B)
                    )
                )
            )
            .border(
                width = 1.dp,
                color = if (isChecked) AmberGoldPrimary.copy(alpha = 0.4f) else DarkCardBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(14.dp)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Icon with glowing background
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(colorDot.copy(alpha = if (isChecked) 0.2f else 0.08f))
                        .border(
                            width = 1.dp,
                            color = colorDot.copy(alpha = if (isChecked) 0.6f else 0.2f),
                            shape = RoundedCornerShape(10.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isChecked) colorDot else TextMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (isChecked) colorDot else TextMuted)
                        )
                        Text(
                            text = title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isChecked) TextPrimary else TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = TextMuted,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Switch
            Switch(
                checked = isChecked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AmberGoldPrimary,
                    checkedTrackColor = AmberGoldDark.copy(alpha = 0.4f),
                    checkedBorderColor = AmberGoldPrimary,
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = DarkSurfaceVariant,
                    uncheckedBorderColor = DarkCardBorder
                ),
                modifier = Modifier.testTag("${tag}_switch")
            )
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary
        )
    }
}
