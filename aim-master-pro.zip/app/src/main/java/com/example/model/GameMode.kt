package com.example.model

enum class GameMode(
    val title: String,
    val subtitle: String,
    val isActiveStatus: Boolean,
    val tableAspectRatio: Float, // width / height: 1.0f for Square Carrom Board
    val pocketCount: Int,
    val description: String
) {
    CARROM_DISC_POOL(
        title = "Carrom Disc Pool",
        subtitle = "Active Pro Engine",
        isActiveStatus = true,
        tableAspectRatio = 1.0f, // Square 1:1 Carrom board
        pocketCount = 4,
        description = "Precision 4-corner pocket puck reflections & striker trajectory"
    );

    fun getDisplayName(): String {
        return "$title (Active)"
    }
}

