package com.example.model

import androidx.compose.ui.graphics.Color
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vec2(val x: Float, val y: Float) {
    operator fun plus(other: Vec2) = Vec2(x + other.x, y + other.y)
    operator fun minus(other: Vec2) = Vec2(x - other.x, y - other.y)
    operator fun times(scalar: Float) = Vec2(x * scalar, y * scalar)
    operator fun div(scalar: Float) = if (scalar != 0f) Vec2(x / scalar, y / scalar) else Vec2(0f, 0f)

    fun length(): Float = sqrt(x * x + y * y)
    
    fun normalized(): Vec2 {
        val len = length()
        return if (len > 0.0001f) Vec2(x / len, y / len) else Vec2(0f, 0f)
    }

    fun dot(other: Vec2): Float = x * other.x + y * other.y

    fun distanceTo(other: Vec2): Float = (this - other).length()

    fun angle(): Float = atan2(y, x)

    companion object {
        val ZERO = Vec2(0f, 0f)
        fun fromAngle(radians: Float, length: Float = 1f): Vec2 {
            return Vec2(cos(radians) * length, sin(radians) * length)
        }
    }
}

enum class RayType {
    AIM_GUIDE,           // Direct striker ray
    POTTING_TRAJECTORY,  // Green line for potting into pocket
    COLLISION_PATH,      // Red line for cue/striker deflection after hit
    CUSHION_BOUNCE       // Yellow line for cushion reflections
}

data class RaySegment(
    val start: Vec2,
    val end: Vec2,
    val type: RayType,
    val colorArgb: Int,
    val isDashed: Boolean = false,
    val label: String? = null
)

data class AimBall(
    val id: Int,
    var position: Vec2,
    val radius: Float,
    val isStriker: Boolean = false,
    val colorArgb: Int = 0xFFF8FAFC.toInt(),
    val label: String = ""
)

data class AimPocket(
    val position: Vec2,
    val radius: Float,
    val name: String = ""
)

data class TrajectoryResult(
    val rays: List<RaySegment>,
    val targetBallHit: AimBall? = null,
    val targetPocket: AimPocket? = null,
    val hitPoint: Vec2? = null,
    val bouncePoints: List<Vec2> = emptyList(),
    val potSuccessProbability: Int = 98,
    val angleDegrees: Float = 0f
)
