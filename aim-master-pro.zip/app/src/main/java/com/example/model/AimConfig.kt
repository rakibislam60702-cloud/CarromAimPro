package com.example.model

data class AimConfig(
    val deviceId: String = "#YyoixdZJ",
    val isProMember: Boolean = true,
    val selectedGame: GameMode = GameMode.CARROM_DISC_POOL,
    val isMultiRayLaser: Boolean = true,      // "Multi-Ray Laser Aim"
    val isAutoCushionReflection: Boolean = true, // "Auto Cushion Reflection"
    val isAutoTargetPocket: Boolean = true,   // "Auto Target Pocket"
    val isCloudEngineRunning: Boolean = false,
    val laserRayCount: Int = 3,
    val laserThickness: Float = 4f,
    val showAngles: Boolean = true,
    val passThroughTouch: Boolean = true
)
