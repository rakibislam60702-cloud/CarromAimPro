package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.model.AimConfig
import com.example.model.GameMode
import com.example.service.AimOverlayService
import com.example.ui.AimDashboardScreen
import com.example.ui.theme.MyApplicationTheme
import java.util.UUID

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val deviceId = getOrCreateDeviceId()

        setContent {
            MyApplicationTheme {
                MainContent(
                    initialDeviceId = deviceId,
                    onRequestOverlayPermission = { requestOverlayPermission() }
                )
            }
        }
    }

    private fun getOrCreateDeviceId(): String {
        val prefs = getSharedPreferences("aim_master_prefs", Context.MODE_PRIVATE)
        var id = prefs.getString("device_id", null)
        if (id.isNullOrBlank()) {
            try {
                // Dynamically derive unique hardware identifier from Android system
                val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: ""
                val hardwareSignature = "${Build.BRAND}-${Build.MODEL}-${Build.HARDWARE}-$androidId"
                
                val md = java.security.MessageDigest.getInstance("SHA-256")
                val digest = md.digest(hardwareSignature.toByteArray(Charsets.UTF_8))
                
                // Encode 8-character unique alphanumeric uppercase device ID
                val rawHex = digest.joinToString("") { "%02X".format(it) }
                id = "#" + rawHex.take(8).uppercase()
            } catch (e: Exception) {
                // Fallback to cryptographic UUID
                id = "#" + UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
            }
            prefs.edit().putString("device_id", id).apply()
        }
        return id
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } catch (e: Exception) {
                val fallbackIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                startActivity(fallbackIntent)
            }
        }
    }

    @Composable
    private fun MainContent(
        initialDeviceId: String,
        onRequestOverlayPermission: () -> Unit
    ) {
        val context = this
        val isServiceRunning by AimOverlayService.isServiceRunning.collectAsState()
        val serviceConfig by AimOverlayService.currentConfig.collectAsState()

        var config by remember {
            mutableStateOf(
                AimConfig(
                    deviceId = initialDeviceId,
                    isProMember = true,
                    selectedGame = GameMode.CARROM_DISC_POOL,
                    isMultiRayLaser = true,
                    isAutoCushionReflection = true,
                    isAutoTargetPocket = true
                )
            )
        }

        var hasOverlayPermission by remember {
            mutableStateOf(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Settings.canDrawOverlays(context)
                } else true
            )
        }

        // Notification permission launcher for Android 13+
        val notificationPermissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                Toast.makeText(context, "Notification permission enabled", Toast.LENGTH_SHORT).show()
            }
        }

        // Refresh permission state on resume
        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Settings.canDrawOverlays(context)
                    } else true
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose {
                lifecycleOwner.lifecycle.removeObserver(observer)
            }
        }

        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }

        AimDashboardScreen(
            config = config,
            isEngineRunning = isServiceRunning,
            hasOverlayPermission = hasOverlayPermission,
            onRequestOverlayPermission = onRequestOverlayPermission,
            onToggleEngine = {
                if (!hasOverlayPermission) {
                    Toast.makeText(context, "Please grant Overlay Permission first", Toast.LENGTH_LONG).show()
                    onRequestOverlayPermission()
                } else {
                    if (isServiceRunning) {
                        AimOverlayService.stopService(context)
                        config = config.copy(isCloudEngineRunning = false)
                        Toast.makeText(context, "Aim Cloud Engine Stopped", Toast.LENGTH_SHORT).show()
                    } else {
                        AimOverlayService.startService(context, config)
                        config = config.copy(isCloudEngineRunning = true)
                        Toast.makeText(context, "⚡ Aim Cloud Engine Launched! Trajectory overlay active.", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onConfigChange = { newConfig ->
                config = newConfig
                if (isServiceRunning) {
                    AimOverlayService.updateServiceConfig(context, newConfig)
                }
            }
        )
    }
}
