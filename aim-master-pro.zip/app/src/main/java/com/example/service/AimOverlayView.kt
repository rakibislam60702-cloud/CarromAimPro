package com.example.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import com.example.model.AimBall
import com.example.model.AimConfig
import com.example.model.AimPocket
import com.example.model.GameMode
import com.example.model.RayType
import com.example.model.TrajectoryResult
import com.example.model.Vec2
import com.example.physics.AimPhysicsEngine
import kotlin.math.cos
import kotlin.math.sin

class AimOverlayView(
    context: Context,
    var config: AimConfig,
    private val onStopEngineRequested: () -> Unit,
    private val onConfigChanged: (AimConfig) -> Unit
) : View(context) {

    private var strikerPos = Vec2(350f, 1100f)
    private var aimAngleRad = -Math.PI.toFloat() * 0.35f
    private var isDraggingStriker = false
    private var isDraggingAimReticle = false
    private var isHudMinimized = false
    private var isHudDragging = false

    // Floating HUD window position
    private var hudPos = PointF(40f, 140f)
    private var hudDragStart = PointF(0f, 0f)
    private var hudInitialPos = PointF(0f, 0f)

    // Interactive balls on overlay canvas
    private val targetBalls = mutableListOf<AimBall>()
    private val pockets = mutableListOf<AimPocket>()
    private val tableBounds = RectF()

    // Paints
    private val greenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AimPhysicsEngine.COLOR_GREEN_POTTING
        strokeWidth = 6f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val greenGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 0, 245, 212)
        strokeWidth = 14f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val redPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AimPhysicsEngine.COLOR_RED_COLLISION
        strokeWidth = 6f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val redGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 255, 51, 102)
        strokeWidth = 14f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val yellowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AimPhysicsEngine.COLOR_YELLOW_CUSHION
        strokeWidth = 5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val yellowGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 255, 209, 102)
        strokeWidth = 12f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val aimRayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AimPhysicsEngine.COLOR_AIM_RAY
        strokeWidth = 5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val dashedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 255, 183, 3)
        strokeWidth = 3f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(15f, 10f), 0f)
    }

    private val hudBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(235, 19, 23, 34)
        style = Paint.Style.FILL
    }

    private val hudBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 255, 183, 3)
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }

    private val textTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 34f
        isFakeBoldText = true
    }

    private val textSubtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 183, 3)
        textSize = 24f
        isFakeBoldText = true
    }

    private val textSmallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 200, 210, 225)
        textSize = 22f
    }

    private val buttonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 16, 185, 129)
        style = Paint.Style.FILL
    }

    private var pulsePhase = 0f
    private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulsePhase = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        pulseAnimator.start()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        setupVirtualBoard(w.toFloat(), h.toFloat())
    }

    fun updateConfig(newConfig: AimConfig) {
        this.config = newConfig
        setupVirtualBoard(width.toFloat(), height.toFloat())
        invalidate()
    }

    private fun setupVirtualBoard(w: Float, h: Float) {
        if (w <= 0 || h <= 0) return

        tableBounds.set(30f, 180f, w - 30f, h - 140f)

        targetBalls.clear()
        pockets.clear()

        // 4 Carrom Corner Pockets
        val pRadius = 38f
        pockets.add(AimPocket(Vec2(tableBounds.left + 15f, tableBounds.top + 15f), pRadius, "Top-Left"))
        pockets.add(AimPocket(Vec2(tableBounds.right - 15f, tableBounds.top + 15f), pRadius, "Top-Right"))
        pockets.add(AimPocket(Vec2(tableBounds.left + 15f, tableBounds.bottom - 15f), pRadius, "Bottom-Left"))
        pockets.add(AimPocket(Vec2(tableBounds.right - 15f, tableBounds.bottom - 15f), pRadius, "Bottom-Right"))

        // Carrom Pucks (Red Queen, White Puck, Black Puck)
        val centerX = tableBounds.centerX()
        val centerY = tableBounds.centerY()
        targetBalls.add(AimBall(1, Vec2(centerX, centerY - 100f), 30f, colorArgb = Color.argb(255, 239, 68, 68), label = "Q"))
        targetBalls.add(AimBall(2, Vec2(centerX - 100f, centerY - 180f), 30f, colorArgb = Color.argb(255, 243, 244, 246), label = "W"))
        targetBalls.add(AimBall(3, Vec2(centerX + 90f, centerY - 170f), 30f, colorArgb = Color.argb(255, 31, 41, 55), label = "B"))

        if (strikerPos.x < tableBounds.left || strikerPos.x > tableBounds.right) {
            strikerPos = Vec2(centerX, tableBounds.bottom - 220f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val aimDir = Vec2(cos(aimAngleRad), sin(aimAngleRad))
        val trajectory = AimPhysicsEngine.calculateTrajectory(
            strikerPos = strikerPos,
            aimDirection = aimDir,
            balls = targetBalls,
            pockets = pockets,
            tableBounds = tableBounds,
            config = config
        )

        // Draw Table boundary guide (subtle neon boundary)
        drawTableFrame(canvas)

        // Draw Trajectory Rays (Green, Red, Yellow)
        drawTrajectories(canvas, trajectory)

        // Draw Pockets
        drawPockets(canvas)

        // Draw Target Balls
        drawBalls(canvas)

        // Draw Striker & Aim Reticle
        drawStriker(canvas)

        // Draw Floating HUD Pill / Control Panel
        drawFloatingHud(canvas, trajectory)
    }

    private fun drawTableFrame(canvas: Canvas) {
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(40, 255, 183, 3)
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
        canvas.drawRoundRect(tableBounds, 24f, 24f, framePaint)
    }

    private fun drawTrajectories(canvas: Canvas, trajectory: TrajectoryResult) {
        for (ray in trajectory.rays) {
            when (ray.type) {
                RayType.POTTING_TRAJECTORY -> {
                    // GREEN POT LINE: Glowing pot line into pocket
                    canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, greenGlowPaint)
                    canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, greenPaint)

                    // Target pocket pulsing entry beacon
                    val pulseR = 24f + pulsePhase * 18f
                    val beaconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb((180 * (1f - pulsePhase)).toInt(), 0, 245, 212)
                        style = Paint.Style.STROKE
                        strokeWidth = 4f
                    }
                    canvas.drawCircle(ray.end.x, ray.end.y, pulseR, beaconPaint)
                    canvas.drawCircle(ray.end.x, ray.end.y, 8f, Paint().apply { color = AimPhysicsEngine.COLOR_GREEN_POTTING })
                }
                RayType.COLLISION_PATH -> {
                    // RED COLLISION DEFLECTION PATH
                    canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, redGlowPaint)
                    canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, redPaint)

                    // Impact contact point indicator
                    canvas.drawCircle(ray.start.x, ray.start.y, 7f, Paint().apply { color = AimPhysicsEngine.COLOR_RED_COLLISION })
                }
                RayType.CUSHION_BOUNCE -> {
                    // YELLOW CUSHION BOUNCE REFLECTION
                    canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, yellowGlowPaint)
                    canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, yellowPaint)

                    // Cushion bounce star point
                    val bounceGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb(180, 255, 209, 102)
                        style = Paint.Style.FILL
                    }
                    canvas.drawCircle(ray.start.x, ray.start.y, 6f, bounceGlow)
                }
                RayType.AIM_GUIDE -> {
                    if (ray.isDashed) {
                        canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, dashedPaint)
                    } else {
                        canvas.drawLine(ray.start.x, ray.start.y, ray.end.x, ray.end.y, aimRayPaint)
                    }
                }
            }
        }
    }

    private fun drawPockets(canvas: Canvas) {
        val pocketFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(160, 9, 10, 15)
            style = Paint.Style.FILL
        }
        val pocketRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(140, 255, 183, 3)
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
        for (pocket in pockets) {
            canvas.drawCircle(pocket.position.x, pocket.position.y, pocket.radius, pocketFill)
            canvas.drawCircle(pocket.position.x, pocket.position.y, pocket.radius, pocketRim)
        }
    }

    private fun drawBalls(canvas: Canvas) {
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 22f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        for (ball in targetBalls) {
            val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ball.colorArgb
                style = Paint.Style.FILL
            }
            val ballRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(200, 255, 255, 255)
                strokeWidth = 2.5f
                style = Paint.Style.STROKE
            }
            canvas.drawCircle(ball.position.x, ball.position.y, ball.radius, ballPaint)
            canvas.drawCircle(ball.position.x, ball.position.y, ball.radius, ballRing)
            if (ball.label.isNotEmpty()) {
                canvas.drawText(ball.label, ball.position.x, ball.position.y + 7f, textPaint)
            }
        }
    }

    private fun drawStriker(canvas: Canvas) {
        val strikerRadius = 40f

        // Pulsing glow ring around striker
        val strikerGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((90 * (1f - pulsePhase * 0.5f)).toInt(), 56, 189, 248)
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        canvas.drawCircle(strikerPos.x, strikerPos.y, strikerRadius + pulsePhase * 10f, strikerGlow)

        // Striker body
        val strikerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(220, 19, 23, 34)
            style = Paint.Style.FILL
        }
        val strikerRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(255, 56, 189, 248)
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        canvas.drawCircle(strikerPos.x, strikerPos.y, strikerRadius, strikerPaint)
        canvas.drawCircle(strikerPos.x, strikerPos.y, strikerRadius, strikerRim)

        // Aim controller handle reticle
        val aimHandleDistance = 140f
        val handleX = strikerPos.x + cos(aimAngleRad) * aimHandleDistance
        val handleY = strikerPos.y + sin(aimAngleRad) * aimHandleDistance

        // Line connecting striker to aim handle
        val handleLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(180, 255, 183, 3)
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(strikerPos.x, strikerPos.y, handleX, handleY, handleLine)

        // Drag handle ring
        val handleRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(255, 255, 183, 3)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(handleX, handleY, 18f, handleRing)
        canvas.drawCircle(handleX, handleY, 26f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(120, 255, 183, 3)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        })
    }

    private fun drawFloatingHud(canvas: Canvas, trajectory: TrajectoryResult) {
        val hX = hudPos.x
        val hY = hudPos.y

        if (isHudMinimized) {
            // Minimized Floating Badge
            val pillRect = RectF(hX, hY, hX + 220f, hY + 68f)
            canvas.drawRoundRect(pillRect, 34f, 34f, hudBgPaint)
            canvas.drawRoundRect(pillRect, 34f, 34f, hudBorderPaint)

            // Live green dot
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AimPhysicsEngine.COLOR_GREEN_POTTING
                style = Paint.Style.FILL
            }
            canvas.drawCircle(hX + 32f, hY + 34f, 8f, dotPaint)

            val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 24f
                isFakeBoldText = true
            }
            canvas.drawText("AIM PRO", hX + 54f, hY + 42f, badgeText)
            return
        }

        // Expanded Floating Control Panel
        val hudWidth = 460f
        val hudHeight = 310f
        val hudRect = RectF(hX, hY, hX + hudWidth, hY + hudHeight)

        canvas.drawRoundRect(hudRect, 24f, 24f, hudBgPaint)
        canvas.drawRoundRect(hudRect, 24f, 24f, hudBorderPaint)

        // Header
        canvas.drawText("⚡ AIM MASTER CLOUD", hX + 24f, hY + 44f, textTitlePaint)
        val subtitle = "${config.selectedGame.title} • PRO ACTIVE"
        canvas.drawText(subtitle, hX + 24f, hY + 74f, textSubtitlePaint)

        // Telemetry stats
        val potProb = "${trajectory.potSuccessProbability}% POT CHANCE"
        canvas.drawText("Accuracy: $potProb", hX + 24f, hY + 110f, textSmallPaint)
        val bounceText = if (config.isAutoCushionReflection) "Cushion: 2-Rail Auto Bounce" else "Cushion: Off"
        canvas.drawText(bounceText, hX + 24f, hY + 138f, textSmallPaint)
        val laserText = if (config.isMultiRayLaser) "Laser: Multi-Ray 3X Active" else "Laser: Single Ray"
        canvas.drawText(laserText, hX + 24f, hY + 166f, textSmallPaint)

        // Feature Toggle Buttons row inside HUD
        val btnY = hY + 190f
        drawMiniToggle(canvas, hX + 24f, btnY, "Multi-Ray", config.isMultiRayLaser)
        drawMiniToggle(canvas, hX + 160f, btnY, "Cushion", config.isAutoCushionReflection)
        drawMiniToggle(canvas, hX + 296f, btnY, "Pocket", config.isAutoTargetPocket)

        // Stop Engine Action Button
        val stopBtnRect = RectF(hX + 24f, hY + 246f, hX + hudWidth - 24f, hY + 294f)
        val stopBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(220, 239, 68, 68)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(stopBtnRect, 16f, 16f, stopBg)
        val stopText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 24f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("STOP CLOUD ENGINE", stopBtnRect.centerX(), stopBtnRect.centerY() + 8f, stopText)

        // Minimize icon in top right corner
        val minPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(180, 255, 183, 3)
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(hX + hudWidth - 44f, hY + 28f, hX + hudWidth - 24f, hY + 28f, minPaint)
    }

    private fun drawMiniToggle(canvas: Canvas, x: Float, y: Float, title: String, active: Boolean) {
        val rect = RectF(x, y, x + 120f, y + 42f)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (active) Color.argb(180, 16, 185, 129) else Color.argb(120, 40, 48, 68)
            style = Paint.Style.FILL
        }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (active) Color.argb(240, 16, 185, 129) else Color.argb(80, 200, 210, 225)
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (active) Color.WHITE else Color.argb(180, 200, 210, 225)
            textSize = 19f
            isFakeBoldText = active
            textAlign = Paint.Align.CENTER
        }
        canvas.drawRoundRect(rect, 10f, 10f, bg)
        canvas.drawRoundRect(rect, 10f, 10f, border)
        canvas.drawText(title, rect.centerX(), rect.centerY() + 6f, text)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val touchX = event.x
        val touchY = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // Check if touch is on HUD
                val hudWidth = if (isHudMinimized) 220f else 460f
                val hudHeight = if (isHudMinimized) 68f else 310f
                val hudRect = RectF(hudPos.x, hudPos.y, hudPos.x + hudWidth, hudPos.y + hudHeight)

                if (hudRect.contains(touchX, touchY)) {
                    if (isHudMinimized) {
                        isHudMinimized = false
                        invalidate()
                        return true
                    }

                    // Check minimize button
                    if (touchX >= hudPos.x + hudWidth - 60f && touchY <= hudPos.y + 60f) {
                        isHudMinimized = true
                        invalidate()
                        return true
                    }

                    // Check Stop Button
                    val stopBtnRect = RectF(hudPos.x + 24f, hudPos.y + 246f, hudPos.x + hudWidth - 24f, hudPos.y + 294f)
                    if (stopBtnRect.contains(touchX, touchY)) {
                        onStopEngineRequested()
                        return true
                    }

                    // Check Mini Toggles
                    val btnY = hudPos.y + 190f
                    if (touchY in btnY..(btnY + 42f)) {
                        if (touchX in (hudPos.x + 24f)..(hudPos.x + 144f)) {
                            config = config.copy(isMultiRayLaser = !config.isMultiRayLaser)
                            onConfigChanged(config)
                            invalidate()
                            return true
                        }
                        if (touchX in (hudPos.x + 160f)..(hudPos.x + 280f)) {
                            config = config.copy(isAutoCushionReflection = !config.isAutoCushionReflection)
                            onConfigChanged(config)
                            invalidate()
                            return true
                        }
                        if (touchX in (hudPos.x + 296f)..(hudPos.x + 416f)) {
                            config = config.copy(isAutoTargetPocket = !config.isAutoTargetPocket)
                            onConfigChanged(config)
                            invalidate()
                            return true
                        }
                    }

                    // Dragging HUD
                    isHudDragging = true
                    hudDragStart.set(touchX, touchY)
                    hudInitialPos.set(hudPos.x, hudPos.y)
                    return true
                }

                // Check striker touch
                val distToStriker = Vec2(touchX, touchY).distanceTo(strikerPos)
                if (distToStriker <= 70f) {
                    isDraggingStriker = true
                    return true
                }

                // Check aim handle touch
                val aimHandleDistance = 140f
                val handlePos = Vec2(
                    strikerPos.x + cos(aimAngleRad) * aimHandleDistance,
                    strikerPos.y + sin(aimAngleRad) * aimHandleDistance
                )
                if (Vec2(touchX, touchY).distanceTo(handlePos) <= 60f) {
                    isDraggingAimReticle = true
                    return true
                }

                // Check object balls dragging
                for (ball in targetBalls) {
                    if (Vec2(touchX, touchY).distanceTo(ball.position) <= ball.radius * 1.5f) {
                        ball.position = Vec2(touchX, touchY)
                        invalidate()
                        return true
                    }
                }

                // Otherwise, tap to aim towards point
                val diff = Vec2(touchX, touchY) - strikerPos
                aimAngleRad = diff.angle()
                invalidate()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (isHudDragging) {
                    val dx = touchX - hudDragStart.x
                    val dy = touchY - hudDragStart.y
                    hudPos.x = (hudInitialPos.x + dx).coerceIn(10f, width - 200f)
                    hudPos.y = (hudInitialPos.y + dy).coerceIn(40f, height - 100f)
                    invalidate()
                    return true
                }
                if (isDraggingStriker) {
                    strikerPos = Vec2(
                        touchX.coerceIn(tableBounds.left + 40f, tableBounds.right - 40f),
                        touchY.coerceIn(tableBounds.top + 40f, tableBounds.bottom - 40f)
                    )
                    invalidate()
                    return true
                }
                if (isDraggingAimReticle) {
                    val diff = Vec2(touchX, touchY) - strikerPos
                    aimAngleRad = diff.angle()
                    invalidate()
                    return true
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDraggingStriker = false
                isDraggingAimReticle = false
                isHudDragging = false
            }
        }
        return super.onTouchEvent(event)
    }
}
