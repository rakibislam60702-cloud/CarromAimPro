package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.AimConfig
import com.example.model.GameMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AimOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: AimOverlayView? = null

    companion object {
        const val CHANNEL_ID = "aim_master_cloud_engine_channel"
        const val NOTIFICATION_ID = 2026

        const val ACTION_START = "com.example.aimmaster.ACTION_START"
        const val ACTION_STOP = "com.example.aimmaster.ACTION_STOP"
        const val ACTION_UPDATE = "com.example.aimmaster.ACTION_UPDATE"

        const val EXTRA_GAME_MODE = "EXTRA_GAME_MODE"
        const val EXTRA_MULTI_RAY = "EXTRA_MULTI_RAY"
        const val EXTRA_CUSHION = "EXTRA_CUSHION"
        const val EXTRA_POCKET = "EXTRA_POCKET"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val _currentConfig = MutableStateFlow(AimConfig())
        val currentConfig: StateFlow<AimConfig> = _currentConfig.asStateFlow()

        fun startService(context: Context, config: AimConfig) {
            val intent = Intent(context, AimOverlayService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_GAME_MODE, config.selectedGame.name)
                putExtra(EXTRA_MULTI_RAY, config.isMultiRayLaser)
                putExtra(EXTRA_CUSHION, config.isAutoCushionReflection)
                putExtra(EXTRA_POCKET, config.isAutoTargetPocket)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, AimOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun updateServiceConfig(context: Context, config: AimConfig) {
            val intent = Intent(context, AimOverlayService::class.java).apply {
                action = ACTION_UPDATE
                putExtra(EXTRA_GAME_MODE, config.selectedGame.name)
                putExtra(EXTRA_MULTI_RAY, config.isMultiRayLaser)
                putExtra(EXTRA_CUSHION, config.isAutoCushionReflection)
                putExtra(EXTRA_POCKET, config.isAutoTargetPocket)
            }
            context.startService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        if (action == ACTION_STOP) {
            removeOverlay()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            _isServiceRunning.value = false
            return START_NOT_STICKY
        }

        val gameModeName = intent?.getStringExtra(EXTRA_GAME_MODE) ?: _currentConfig.value.selectedGame.name
        val gameMode = try {
            GameMode.valueOf(gameModeName)
        } catch (e: Exception) {
            GameMode.CARROM_DISC_POOL
        }

        val multiRay = intent?.getBooleanExtra(EXTRA_MULTI_RAY, _currentConfig.value.isMultiRayLaser) ?: true
        val cushion = intent?.getBooleanExtra(EXTRA_CUSHION, _currentConfig.value.isAutoCushionReflection) ?: true
        val pocket = intent?.getBooleanExtra(EXTRA_POCKET, _currentConfig.value.isAutoTargetPocket) ?: true

        val updatedConfig = _currentConfig.value.copy(
            selectedGame = gameMode,
            isMultiRayLaser = multiRay,
            isAutoCushionReflection = cushion,
            isAutoTargetPocket = pocket,
            isCloudEngineRunning = true
        )
        _currentConfig.value = updatedConfig

        startForeground(NOTIFICATION_ID, buildNotification(updatedConfig))
        _isServiceRunning.value = true

        if (Settings.canDrawOverlays(this)) {
            if (overlayView == null) {
                showOverlay(updatedConfig)
            } else {
                overlayView?.updateConfig(updatedConfig)
            }
        }

        return START_STICKY
    }

    private fun showOverlay(config: AimConfig) {
        if (overlayView != null) return

        overlayView = AimOverlayView(
            context = this,
            config = config,
            onStopEngineRequested = {
                stopService(this)
            },
            onConfigChanged = { newConfig ->
                _currentConfig.value = newConfig
                val notif = buildNotification(newConfig)
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(NOTIFICATION_ID, notif)
            }
        )

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeOverlay() {
        overlayView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayView = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Aim Master Cloud Engine",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground trajectory prediction and multi-ray overlay engine"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(config: AimConfig): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AimOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = "${config.selectedGame.title} • 120 FPS Cloud Aim Active"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Aim Master PRO Engine Active")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Engine", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        _isServiceRunning.value = false
        _currentConfig.value = _currentConfig.value.copy(isCloudEngineRunning = false)
    }
}
