package com.example.physics

import android.graphics.RectF
import com.example.model.AimBall
import com.example.model.AimConfig
import com.example.model.AimPocket
import com.example.model.RaySegment
import com.example.model.RayType
import com.example.model.TrajectoryResult
import com.example.model.Vec2
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object AimPhysicsEngine {

    // Trajectory Colors (ARGB)
    val COLOR_GREEN_POTTING = 0xFF00F5D4.toInt()   // Potting trajectory to pocket
    val COLOR_RED_COLLISION = 0xFFFF3366.toInt()   // Striker deflection / collision path
    val COLOR_YELLOW_CUSHION = 0xFFFFD166.toInt()  // Cushion reflection
    val COLOR_AIM_RAY = 0xFFFFB703.toInt()         // Direct aim ray

    /**
     * Calculates the full trajectory paths including:
     * - Direct striker aim ray
     * - Collision detection against object balls
     * - Cushion bounce calculation if cushion reflection is enabled
     * - Potting trajectory line (Green) from target ball to target pocket
     * - Deflection path (Red) of striker
     * - Cushion reflections (Yellow)
     */
    fun calculateTrajectory(
        strikerPos: Vec2,
        aimDirection: Vec2,
        balls: List<AimBall>,
        pockets: List<AimPocket>,
        tableBounds: RectF,
        config: AimConfig,
        maxRayDistance: Float = 2500f
    ): TrajectoryResult {
        val rays = mutableListOf<RaySegment>()
        val bouncePoints = mutableListOf<Vec2>()

        var currentStart = strikerPos
        var currentDir = aimDirection.normalized()
        var remainingDistance = maxRayDistance
        var hitBall: AimBall? = null
        var hitPoint: Vec2? = null
        var targetPocket: AimPocket? = null

        // 1. Trace Ray from striker through space, detecting cushion bounces and ball collisions
        val maxBounces = if (config.isAutoCushionReflection) 2 else 0

        for (bounceIndex in 0..maxBounces) {
            // Find closest ball collision along current ray
            val ballCollision = findFirstBallCollision(currentStart, currentDir, balls, remainingDistance)

            // Find closest table cushion collision
            val cushionCollision = findCushionCollision(currentStart, currentDir, tableBounds)

            if (ballCollision != null && (cushionCollision == null || ballCollision.distance < cushionCollision.distance)) {
                // Ball was hit!
                hitBall = ballCollision.ball
                hitPoint = ballCollision.impactPoint
                val hitDist = ballCollision.distance

                // Add striker travel ray (Yellow/Amber or Aim ray)
                val rayColor = if (bounceIndex > 0) COLOR_YELLOW_CUSHION else COLOR_AIM_RAY
                val rayType = if (bounceIndex > 0) RayType.CUSHION_BOUNCE else RayType.AIM_GUIDE
                rays.add(
                    RaySegment(
                        start = currentStart,
                        end = hitPoint,
                        type = rayType,
                        colorArgb = rayColor,
                        label = if (bounceIndex > 0) "Cushion Bounce #$bounceIndex" else "Aim Ray"
                    )
                )

                // Calculate physics deflection vectors at collision point
                val normal = (hitBall.position - hitPoint).normalized()
                val tangent = Vec2(-normal.y, normal.x)

                // Target ball (object ball) moves in direction of center-to-center normal
                var objectBallDir = normal
                if (config.isAutoTargetPocket && pockets.isNotEmpty()) {
                    // Find closest/best pocket that aligns with object ball velocity
                    val bestPocket = findBestPocketForBall(hitBall.position, objectBallDir, pockets)
                    if (bestPocket != null) {
                        targetPocket = bestPocket
                    }
                }

                // If no specific pocket found, find closest pocket in general direction
                if (targetPocket == null && pockets.isNotEmpty()) {
                    targetPocket = pockets.minByOrNull { it.position.distanceTo(hitBall.position) }
                }

                val endPocketPos = targetPocket?.position ?: (hitBall.position + objectBallDir * 350f)

                // 2. GREEN LINE: Potting Trajectory
                rays.add(
                    RaySegment(
                        start = hitBall.position,
                        end = endPocketPos,
                        type = RayType.POTTING_TRAJECTORY,
                        colorArgb = COLOR_GREEN_POTTING,
                        label = "Potting Trajectory"
                    )
                )

                // 3. RED LINE: Striker Collision Deflection
                // Striker deflection angle based on collision tangent
                val v1DotT = currentDir.dot(tangent)
                val strikerDeflectionDir = (tangent * v1DotT).normalized()
                val strikerEnd = hitPoint + (if (strikerDeflectionDir.length() > 0.1f) strikerDeflectionDir else Vec2(-objectBallDir.y, objectBallDir.x)) * 280f

                rays.add(
                    RaySegment(
                        start = hitPoint,
                        end = strikerEnd,
                        type = RayType.COLLISION_PATH,
                        colorArgb = COLOR_RED_COLLISION,
                        label = "Collision Path"
                    )
                )

                // 4. Multi-Ray Laser Extension if enabled
                if (config.isMultiRayLaser) {
                    // Add secondary prediction rays (parallel ghost guides)
                    val perp = Vec2(-currentDir.y, currentDir.x) * 16f
                    rays.add(
                        RaySegment(
                            start = currentStart + perp,
                            end = hitPoint + perp,
                            type = RayType.AIM_GUIDE,
                            colorArgb = 0x80FFB703.toInt(),
                            isDashed = true
                        )
                    )
                    rays.add(
                        RaySegment(
                            start = currentStart - perp,
                            end = hitPoint - perp,
                            type = RayType.AIM_GUIDE,
                            colorArgb = 0x80FFB703.toInt(),
                            isDashed = true
                        )
                    )
                }

                break
            } else if (cushionCollision != null && cushionCollision.distance < remainingDistance) {
                // Ray hit the cushion table rail!
                val bouncePos = cushionCollision.hitPoint
                bouncePoints.add(bouncePos)

                val rayColor = if (bounceIndex == 0) COLOR_AIM_RAY else COLOR_YELLOW_CUSHION
                val rayType = if (bounceIndex == 0) RayType.AIM_GUIDE else RayType.CUSHION_BOUNCE
                rays.add(
                    RaySegment(
                        start = currentStart,
                        end = bouncePos,
                        type = rayType,
                        colorArgb = rayColor,
                        label = "Cushion Bounce #${bounceIndex + 1}"
                    )
                )

                if (!config.isAutoCushionReflection) {
                    break
                }

                // Reflect direction vector across cushion normal
                val normal = cushionCollision.normal
                currentDir = (currentDir - normal * (2f * currentDir.dot(normal))).normalized()
                currentStart = bouncePos + currentDir * 2f
                remainingDistance -= cushionCollision.distance
            } else {
                // Ray goes unobstructed
                val endPoint = currentStart + currentDir * remainingDistance
                rays.add(
                    RaySegment(
                        start = currentStart,
                        end = endPoint,
                        type = RayType.AIM_GUIDE,
                        colorArgb = COLOR_AIM_RAY
                    )
                )
                break
            }
        }

        // Calculate precision probability score
        val angleDeg = Math.toDegrees(atan2(currentDir.y.toDouble(), currentDir.x.toDouble())).toFloat()
        val potProb = if (hitBall != null && targetPocket != null) {
            val toPocket = (targetPocket.position - hitBall.position).normalized()
            val impactToPocketDot = (hitBall.position - (hitPoint ?: hitBall.position)).normalized().dot(toPocket)
            val score = (impactToPocketDot * 100).toInt().coerceIn(72, 99)
            score
        } else {
            95
        }

        return TrajectoryResult(
            rays = rays,
            targetBallHit = hitBall,
            targetPocket = targetPocket,
            hitPoint = hitPoint,
            bouncePoints = bouncePoints,
            potSuccessProbability = potProb,
            angleDegrees = abs(angleDeg)
        )
    }

    private data class BallCollision(
        val ball: AimBall,
        val impactPoint: Vec2,
        val distance: Float
    )

    private fun findFirstBallCollision(
        origin: Vec2,
        direction: Vec2,
        balls: List<AimBall>,
        maxDist: Float
    ): BallCollision? {
        var closest: BallCollision? = null
        var minD = maxDist

        for (ball in balls) {
            if (ball.isStriker) continue

            val toBall = ball.position - origin
            val projection = toBall.dot(direction)
            if (projection < 0) continue // Ball is behind origin

            val closestPointOnRay = origin + direction * projection
            val distToRay = (ball.position - closestPointOnRay).length()

            val combinedRadius = ball.radius * 1.8f // Proximity radius for striker + ball contact
            if (distToRay <= combinedRadius) {
                // Intersection distance calculation: d = projection - sqrt(R^2 - h^2)
                val halfChord = sqrt((combinedRadius * combinedRadius - distToRay * distToRay).coerceAtLeast(0f))
                val collisionDist = projection - halfChord
                if (collisionDist in 0f..minD) {
                    minD = collisionDist
                    val impactPoint = origin + direction * collisionDist
                    closest = BallCollision(ball, impactPoint, collisionDist)
                }
            }
        }
        return closest
    }

    private data class CushionCollision(
        val hitPoint: Vec2,
        val normal: Vec2,
        val distance: Float
    )

    private fun findCushionCollision(
        origin: Vec2,
        direction: Vec2,
        bounds: RectF
    ): CushionCollision? {
        var closestDist = Float.MAX_VALUE
        var bestHit: Vec2? = null
        var bestNormal: Vec2? = null

        // Left cushion (x = bounds.left, normal = (1, 0))
        if (direction.x < -0.0001f) {
            val d = (bounds.left - origin.x) / direction.x
            val y = origin.y + direction.y * d
            if (d > 0 && y >= bounds.top && y <= bounds.bottom && d < closestDist) {
                closestDist = d
                bestHit = Vec2(bounds.left, y)
                bestNormal = Vec2(1f, 0f)
            }
        }
        // Right cushion (x = bounds.right, normal = (-1, 0))
        if (direction.x > 0.0001f) {
            val d = (bounds.right - origin.x) / direction.x
            val y = origin.y + direction.y * d
            if (d > 0 && y >= bounds.top && y <= bounds.bottom && d < closestDist) {
                closestDist = d
                bestHit = Vec2(bounds.right, y)
                bestNormal = Vec2(-1f, 0f)
            }
        }
        // Top cushion (y = bounds.top, normal = (0, 1))
        if (direction.y < -0.0001f) {
            val d = (bounds.top - origin.y) / direction.y
            val x = origin.x + direction.x * d
            if (d > 0 && x >= bounds.left && x <= bounds.right && d < closestDist) {
                closestDist = d
                bestHit = Vec2(x, bounds.top)
                bestNormal = Vec2(0f, 1f)
            }
        }
        // Bottom cushion (y = bounds.bottom, normal = (0, -1))
        if (direction.y > 0.0001f) {
            val d = (bounds.bottom - origin.y) / direction.y
            val x = origin.x + direction.x * d
            if (d > 0 && x >= bounds.left && x <= bounds.right && d < closestDist) {
                closestDist = d
                bestHit = Vec2(x, bounds.bottom)
                bestNormal = Vec2(0f, -1f)
            }
        }

        return if (bestHit != null && bestNormal != null) {
            CushionCollision(bestHit, bestNormal, closestDist)
        } else null
    }

    private fun findBestPocketForBall(
        ballPos: Vec2,
        ballDir: Vec2,
        pockets: List<AimPocket>
    ): AimPocket? {
        return pockets.maxByOrNull { pocket ->
            val toPocket = (pocket.position - ballPos).normalized()
            ballDir.dot(toPocket)
        }
    }
}
