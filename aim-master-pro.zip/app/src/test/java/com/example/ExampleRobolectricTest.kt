package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.AimConfig
import com.example.model.GameMode
import com.example.model.Vec2
import com.example.physics.AimPhysicsEngine
import android.graphics.RectF
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Aim Master PRO", appName)
  }

  @Test
  fun `test trajectory calculation generates valid rays`() {
    val config = AimConfig(
      selectedGame = GameMode.CARROM_DISC_POOL,
      isMultiRayLaser = true,
      isAutoCushionReflection = true,
      isAutoTargetPocket = true
    )
    val result = AimPhysicsEngine.calculateTrajectory(
      strikerPos = Vec2(200f, 300f),
      aimDirection = Vec2(0f, -1f),
      balls = emptyList(),
      pockets = emptyList(),
      tableBounds = RectF(0f, 0f, 400f, 400f),
      config = config
    )
    assertNotNull(result)
    assertTrue(result.rays.isNotEmpty())
  }
}

